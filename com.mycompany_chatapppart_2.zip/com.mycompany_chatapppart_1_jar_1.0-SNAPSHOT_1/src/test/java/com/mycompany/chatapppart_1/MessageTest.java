package com.mycompany.chatapppart_1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MessageTest {

    
    public void testMessageLengthValid() {

        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight?"
        );

        assertEquals(
                "Message ready to send.",
                msg.checkMessageLength()
        );
    }


    public void testMessageLengthInvalid() {

        String longMessage = "a".repeat(260);

        Message msg = new Message(
                0,
                "+27718693002",
                longMessage
        );

        assertEquals(
                "Message exceeds 250 characters by 10; please reduce the size.",
                msg.checkMessageLength()
        );
    }

    
    public void testRecipientNumberValid() {

        Message msg = new Message(
                0,
                "08575975889",
                "Hi Keegan, did you receive the payment?"
        );

        assertEquals(
                "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                msg.checkRecipientCell()
        );
    }

    public void testMessageHashCreated() {

        Message msg = new Message(
                0,
                "+27718693002",
                "Hi Mike, can you join us for dinner tonight");
    }
}


